# Intégré depuis la branche Sindiely (Laetitia) — module Rapports §5.13
from django.db.models import Count, Sum
from django.db.models.functions import TruncDate
from django.utils.dateparse import parse_date
from drf_spectacular.utils import OpenApiParameter, extend_schema
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.depenses.models import Depense
from apps.achats.models import Achat
from apps.utilisateurs.permissions import IsGerantOrComptable
from apps.ventes.models import DetailVente, Vente

from .serializers import (
    RapportAchatsSerializer,
    RapportDepensesSerializer,
    RapportProduitsSerializer,
    RapportVentesSerializer,
)

_PERIODE_PARAMS = [
    OpenApiParameter(name="date_debut", type=str, description="Date début (YYYY-MM-DD)"),
    OpenApiParameter(name="date_fin", type=str, description="Date fin (YYYY-MM-DD)"),
]

def _parse_periode(request):
    debut = parse_date(request.query_params.get("date_debut", ""))
    fin = parse_date(request.query_params.get("date_fin", ""))
    return debut, fin


@extend_schema(parameters=_PERIODE_PARAMS, responses=RapportVentesSerializer)
@api_view(["GET"])
@permission_classes([IsAuthenticated, IsGerantOrComptable])
def rapport_ventes(request):
    debut, fin = _parse_periode(request)
    qs = Vente.objects.filter(statut="validee")
    if debut:
        qs = qs.filter(date_vente__date__gte=debut)
    if fin:
        qs = qs.filter(date_vente__date__lte=fin)

    total = qs.aggregate(total=Sum("montant_total"))["total"] or 0
    nombre = qs.aggregate(count=Count("id_vente"))["count"] or 0

    par_jour = (
        qs.annotate(jour=TruncDate("date_vente"))
        .values("jour")
        .annotate(total_jour=Sum("montant_total"), tickets=Count("id_vente"))
        .order_by("jour")
    )

    return Response(
        {
            "periode": {
                "debut": str(debut) if debut else None,
                "fin": str(fin) if fin else None,
            },
            "total_ventes": total,
            "nombre_ventes": nombre,
            "detail_par_jour": list(par_jour),
        }
    )


@extend_schema(parameters=_PERIODE_PARAMS, responses=RapportProduitsSerializer)
@api_view(["GET"])
@permission_classes([IsAuthenticated, IsGerantOrComptable])
def rapport_produits(request):
    debut, fin = _parse_periode(request)
    qs = DetailVente.objects.filter(vente__statut="validee")
    if debut:
        qs = qs.filter(vente__date_vente__date__gte=debut)
    if fin:
        qs = qs.filter(vente__date_vente__date__lte=fin)

    top_produits = (
        qs.values("produit__nom")
        .annotate(
            quantite_totale=Sum("quantite"),
            chiffre_affaires=Sum("sous_total"),
        )
        .order_by("-quantite_totale")[:10]
    )

    return Response(
        {
            "periode": {
                "debut": str(debut) if debut else None,
                "fin": str(fin) if fin else None,
            },
            "top_produits": list(top_produits),
        }
    )


@extend_schema(parameters=_PERIODE_PARAMS, responses=RapportDepensesSerializer)
@api_view(["GET"])
@permission_classes([IsAuthenticated, IsGerantOrComptable])
def rapport_depenses(request):
    debut, fin = _parse_periode(request)
    qs = Depense.objects.all()
    if debut:
        qs = qs.filter(date_depense__date__gte=debut)
    if fin:
        qs = qs.filter(date_depense__date__lte=fin)

    total = qs.aggregate(total=Sum("montant"))["total"] or 0
    par_categorie = (
        qs.values("categorie")
        .annotate(total_categorie=Sum("montant"))
        .order_by("-total_categorie")
    )

    return Response(
        {
            "periode": {
                "debut": str(debut) if debut else None,
                "fin": str(fin) if fin else None,
            },
            "total_depenses": total,
            "par_categorie": list(par_categorie),
        }
    )


@extend_schema(parameters=_PERIODE_PARAMS, responses=RapportAchatsSerializer)
@api_view(["GET"])
@permission_classes([IsAuthenticated, IsGerantOrComptable])
def rapport_achats(request):
    debut, fin = _parse_periode(request)
    qs = Achat.objects.filter(statut=Achat.STATUT_VALIDE)
    if debut:
        qs = qs.filter(date_achat__date__gte=debut)
    if fin:
        qs = qs.filter(date_achat__date__lte=fin)

    total = qs.aggregate(total=Sum("montant_total"))["total"] or 0
    nombre = qs.aggregate(count=Count("id_achat"))["count"] or 0

    par_fournisseur = (
        qs.values("fournisseur__raison_sociale")
        .annotate(
            total_fournisseur=Sum("montant_total"),
            nombre_achats=Count("id_achat"),
        )
        .order_by("-total_fournisseur")
    )

    return Response(
        {
            "periode": {
                "debut": str(debut) if debut else None,
                "fin": str(fin) if fin else None,
            },
            "total_achats": total,
            "nombre_achats": nombre,
            "par_fournisseur": list(par_fournisseur),
        }
    )
